# supabase

Module for supabase functionalities. Part of the infra skills.
