# types

Module for types functionalities. Part of the shared skills.
