# utils

Module for utils functionalities. Part of the shared skills.
