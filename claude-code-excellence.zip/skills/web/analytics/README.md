# analytics

Module for analytics functionalities. Part of the web skills.
