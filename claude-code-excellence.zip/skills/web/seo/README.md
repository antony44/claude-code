# seo

Module for seo functionalities. Part of the web skills.
