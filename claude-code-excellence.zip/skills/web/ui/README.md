# ui

Module for ui functionalities. Part of the web skills.
