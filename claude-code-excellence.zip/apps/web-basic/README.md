# web-basic

This is the web-basic application. It serves as a starting point for building a web basic project.
