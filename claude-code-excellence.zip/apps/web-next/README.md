# web-next

This is the web-next application. It serves as a starting point for building a web next project.
