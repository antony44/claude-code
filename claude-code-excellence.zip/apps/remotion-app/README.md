# remotion-app

This is the remotion-app application. It serves as a starting point for building a remotion app project.
