# video

This template provides a starting point for a video project. Copy this to apps/ and customize.
