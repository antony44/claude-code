# saas

This template provides a starting point for a saas project. Copy this to apps/ and customize.
