# landing

This template provides a starting point for a landing project. Copy this to apps/ and customize.
